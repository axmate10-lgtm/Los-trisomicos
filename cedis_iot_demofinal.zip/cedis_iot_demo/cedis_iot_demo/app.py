import base64
import io
import time
from datetime import datetime
from typing import Optional

import qrcode
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from database import get_connection, init_db
from ticket_generator import generar_lote_tickets
from vision_engine import VisionSystem

app = FastAPI(title="CEDIS IoT - Control de Almacen y Vision Artificial")
init_db()

ACTIVE_SESSION = {
    "id_lote": 1,
    "auto_scan_enabled": True,
    "last_event": "Sistema listo. Coloca una etiqueta dentro de la cuadricula roja central.",
    "last_route": "STANDBY",
    "servo_activado": "NINGUNO (NORMAL)",
    "conteo_actual": "0 / 5",
}


def sincronizar_conteo_lote(id_lote: int):
    conn = get_connection()
    row = conn.execute(
        "SELECT CANTIDAD_CAJAS_CONTADA, CANTIDAD_CAJAS_ESPERADA FROM lote_recepcion WHERE ID_LOTE = ?",
        (id_lote,),
    ).fetchone()
    conn.close()
    if row:
        txt = f"{row['CANTIDAD_CAJAS_CONTADA']} / {row['CANTIDAD_CAJAS_ESPERADA']}"
        ACTIVE_SESSION["conteo_actual"] = txt
        vision.lote_conteo_texto = txt


def registrar_lectura_banda(color_detectado: str, qr_detectado: str = ""):
    if not ACTIVE_SESSION["auto_scan_enabled"]:
        return

    conn = get_connection()
    cur = conn.cursor()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    id_lote = ACTIVE_SESSION["id_lote"]

    try:
        qr_codigo = None
        qr_estado = "CORRECTO"
        if qr_detectado and "|" in qr_detectado:
            parts = qr_detectado.split("|")
            qr_codigo = parts[0]
            if len(parts) > 1 and parts[1]:
                color_detectado = parts[1]
            if len(parts) > 2 and parts[2]:
                qr_estado = parts[2]

        cp = cur.execute(
            """
            SELECT cp.ID_COLOR_PRODUCTO, cp.ID_PRODUCTO, cp.ID_PROVEEDOR, cp.NOMBRE_COLOR,
                   p.NOMBRE_PRODUCTO, pr.NOMBRE_PROVEEDOR
            FROM color_producto cp
            JOIN producto p ON p.ID_PRODUCTO = cp.ID_PRODUCTO
            JOIN proveedor pr ON pr.ID_PROVEEDOR = cp.ID_PROVEEDOR
            WHERE cp.NOMBRE_COLOR = ?
            """,
            (color_detectado,),
        ).fetchone()

        if not cp:
            ACTIVE_SESSION["last_event"] = f"[{now_str}] Lectura ignorada: color '{color_detectado}' no catalogado."
            return

        lote_info = cur.execute(
            """
            SELECT lr.ID_LOTE, lr.CANTIDAD_CAJAS_ESPERADA, lr.CANTIDAD_CAJAS_CONTADA,
                   oc.ID_PROVEEDOR AS OC_PROV, ocd.ID_PRODUCTO AS OC_PROD
            FROM lote_recepcion lr
            JOIN orden_compra oc ON oc.ID_OC = lr.ID_OC
            JOIN orden_compra_detalle ocd ON ocd.ID_OC = oc.ID_OC
            WHERE lr.ID_LOTE = ?
            """,
            (id_lote,),
        ).fetchone()

        coincide_oc = (
            lote_info
            and cp["ID_PRODUCTO"] == lote_info["OC_PROD"]
            and cp["ID_PROVEEDOR"] == lote_info["OC_PROV"]
        )

        if qr_estado == "DANADO":
            servo = "SERVO_1"
            servo_desc = "SERVO 1 (CAJA DANADA)"
            ruta = "SERVO_1_DANADA"
            resultado = "RETENIDA_DANADA"
            estado_caja = "DANADO"
        elif qr_estado == "INCORRECTO" or not coincide_oc:
            servo = "SERVO_2"
            servo_desc = "SERVO 2 (NO ESPERADO)"
            ruta = "SERVO_2_NO_ESPERADO"
            resultado = "RETENIDA_NO_ESPERADO"
            estado_caja = "INCORRECTO"
        else:
            servo = "NINGUNO"
            servo_desc = "NINGUNO (NORMAL - PASA)"
            ruta = "NORMAL_ALMACEN_OK"
            resultado = "EXITOSA"
            estado_caja = "CORRECTO"

        codigo_final = qr_codigo or f"CJ-{datetime.now().strftime('%H%M%S')}-{int(time.time()*10)%100}"

        existe = cur.execute("SELECT ID_CAJA FROM caja WHERE CODIGO_CAJA = ?", (codigo_final,)).fetchone()
        if existe:
            vision.servo_state = "SERVO_2"
            vision.servo_label = "SERVO 2 (DUPLICADO)"
            ACTIVE_SESSION["servo_activado"] = "SERVO 2 (DUPLICADO)"
            ACTIVE_SESSION["last_event"] = f"[{now_str}] ALERTA DUPLICADO: {codigo_final} -> SERVO 2."
            return

        cur.execute(
            """
            INSERT INTO caja (CODIGO_CAJA, ID_LOTE, ID_COLOR_PRODUCTO, ESTADO_INSPECCION, CANTIDAD_REAL, RUTA_ASIGNADA, LEIDA, FECHA_LECTURA_BANDA)
            VALUES (?, ?, ?, ?, ?, ?, 1, ?)
            """,
            (codigo_final, id_lote, cp["ID_COLOR_PRODUCTO"], estado_caja, 1, ruta, now_str),
        )
        id_caja = cur.lastrowid

        cur.execute(
            """
            INSERT INTO lectura_banda (ID_CAJA, COLOR_DETECTADO, QR_DETECTADO, RUTA_ACCIONADA, TIMESTAMP_LECTURA, RESULTADO)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (id_caja, color_detectado, qr_detectado or codigo_final, ruta, now_str, resultado),
        )

        nuevo_conteo = (lote_info["CANTIDAD_CAJAS_CONTADA"] or 0) + 1
        esperadas = lote_info["CANTIDAD_CAJAS_ESPERADA"]
        nuevo_estado_lote = 1
        if nuevo_conteo == esperadas:
            nuevo_estado_lote = 2
        elif nuevo_conteo > esperadas:
            nuevo_estado_lote = 4

        cur.execute(
            "UPDATE lote_recepcion SET CANTIDAD_CAJAS_CONTADA = ?, ID_ESTADO_LOTE = ? WHERE ID_LOTE = ?",
            (nuevo_conteo, nuevo_estado_lote, id_lote),
        )

        if servo != "NINGUNO":
            cur.execute(
                """
                INSERT INTO orden_trabajo (ID_LOTE, ID_TIPO_INCIDENCIA, ID_ESTADO_ORDEN_TRABAJO, DESCRIPCION, FECHA_CREACION)
                VALUES (?, 1, 1, ?, ?)
                """,
                (id_lote, f"{servo_desc}: Caja {codigo_final} ({cp['NOMBRE_COLOR']} - {cp['NOMBRE_PRODUCTO']})", now_str),
            )
        elif nuevo_conteo > esperadas:
            cur.execute(
                """
                INSERT INTO orden_trabajo (ID_LOTE, ID_TIPO_INCIDENCIA, ID_ESTADO_ORDEN_TRABAJO, DESCRIPCION, FECHA_CREACION)
                VALUES (?, 4, 1, ?, ?)
                """,
                (id_lote, f"Lote {id_lote} excedido ({nuevo_conteo}/{esperadas} cajas)", now_str),
            )

        conn.commit()

        conteo_txt = f"{nuevo_conteo} / {esperadas}"
        vision.servo_state = servo
        vision.servo_label = servo_desc
        vision.lote_conteo_texto = conteo_txt

        ACTIVE_SESSION["servo_activado"] = servo_desc
        ACTIVE_SESSION["conteo_actual"] = conteo_txt
        ACTIVE_SESSION["last_route"] = ruta
        ACTIVE_SESSION["last_event"] = (
            f"[{now_str}] PASA CAJA #{nuevo_conteo}/{esperadas} | {cp['NOMBRE_COLOR']} ({cp['NOMBRE_PRODUCTO']}) -> {servo_desc}"
        )
    finally:
        conn.close()


vision = VisionSystem(on_detection_callback=registrar_lectura_banda)


@app.on_event("startup")
def startup_event():
    sincronizar_conteo_lote(ACTIVE_SESSION["id_lote"])
    vision.start(1)


@app.on_event("shutdown")
def shutdown_event():
    vision.stop()


class InspeccionCajaIn(BaseModel):
    id_lote: int
    id_color_producto: int
    estado_inspeccion: str
    cantidad_real: int


class ConfigVisionIn(BaseModel):
    id_lote: Optional[int] = None
    color_filter: Optional[str] = None
    auto_scan: Optional[bool] = None


def gen_mjpeg(stream_type: str):
    while True:
        with vision.lock:
            frame = vision.raw_jpeg if stream_type == "raw" else vision.filtered_jpeg
        if frame:
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
        time.sleep(0.04)


@app.get("/video/raw")
def video_raw():
    return StreamingResponse(gen_mjpeg("raw"), media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/video/filtered")
def video_filtered():
    return StreamingResponse(gen_mjpeg("filtered"), media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/dashboard")
def get_dashboard():
    conn = get_connection()
    cur = conn.cursor()

    lotes = [
        dict(r)
        for r in cur.execute(
            """
            SELECT lr.ID_LOTE, lr.ID_OC, pr.NOMBRE_PROVEEDOR, p.NOMBRE_PRODUCTO,
                   cp.NOMBRE_COLOR, cp.CODIGO_HEX, cp.ID_COLOR_PRODUCTO,
                   lr.CANTIDAD_CAJAS_ESPERADA, lr.CANTIDAD_CAJAS_CONTADA, el.NOMBRE_ESTADO_LOTE
            FROM lote_recepcion lr
            JOIN orden_compra oc ON oc.ID_OC = lr.ID_OC
            JOIN proveedor pr ON pr.ID_PROVEEDOR = oc.ID_PROVEEDOR
            JOIN orden_compra_detalle ocd ON ocd.ID_OC = oc.ID_OC
            JOIN producto p ON p.ID_PRODUCTO = ocd.ID_PRODUCTO
            JOIN estado_lote el ON el.ID_ESTADO_LOTE = lr.ID_ESTADO_LOTE
            LEFT JOIN color_producto cp ON cp.ID_PRODUCTO = p.ID_PRODUCTO AND cp.ID_PROVEEDOR = pr.ID_PROVEEDOR
            ORDER BY lr.ID_LOTE ASC
            """
        ).fetchall()
    ]

    colores = [
        dict(r)
        for r in cur.execute(
            """
            SELECT cp.*, p.NOMBRE_PRODUCTO, pr.NOMBRE_PROVEEDOR
            FROM color_producto cp
            JOIN producto p ON p.ID_PRODUCTO = cp.ID_PRODUCTO
            JOIN proveedor pr ON pr.ID_PROVEEDOR = cp.ID_PROVEEDOR
            """
        ).fetchall()
    ]

    lecturas = [
        dict(r)
        for r in cur.execute(
            """
            SELECT lb.ID_LECTURA, c.CODIGO_CAJA, c.ID_LOTE, lb.COLOR_DETECTADO,
                   c.ESTADO_INSPECCION, lb.RUTA_ACCIONADA, lb.RESULTADO, lb.TIMESTAMP_LECTURA
            FROM lectura_banda lb
            JOIN caja c ON c.ID_CAJA = lb.ID_CAJA
            ORDER BY lb.ID_LECTURA DESC LIMIT 15
            """
        ).fetchall()
    ]

    ordenes_trabajo = [
        dict(r)
        for r in cur.execute(
            """
            SELECT ot.ID_OT, ot.ID_LOTE, ti.NOMBRE_TIPO_INCIDENCIA, eot.NOMBRE_ESTADO_ORDEN_TRABAJO,
                   ot.DESCRIPCION, ot.FECHA_CREACION
            FROM orden_trabajo ot
            JOIN tipo_incidencia ti ON ti.ID_TIPO_INCIDENCIA = ot.ID_TIPO_INCIDENCIA
            JOIN estado_orden_trabajo eot ON eot.ID_ESTADO_ORDEN_TRABAJO = ot.ID_ESTADO_ORDEN_TRABAJO
            ORDER BY ot.ID_OT DESC LIMIT 10
            """
        ).fetchall()
    ]

    tickets = [
        dict(r)
        for r in cur.execute(
            "SELECT * FROM tickets_simulados ORDER BY ID_TICKET DESC LIMIT 15"
        ).fetchall()
    ]

    conn.close()
    return {
        "session": ACTIVE_SESSION,
        "vision_live": {
            "detected_color": vision.current_color,
            "detected_qr": vision.current_qr,
            "filter": vision.active_color_filter,
        },
        "lotes": lotes,
        "colores": colores,
        "lecturas": lecturas,
        "ordenes_trabajo": ordenes_trabajo,
        "tickets": tickets,
    }


@app.post("/api/config")
def update_config(cfg: ConfigVisionIn):
    if cfg.id_lote is not None:
        ACTIVE_SESSION["id_lote"] = cfg.id_lote
        sincronizar_conteo_lote(cfg.id_lote)
    if cfg.color_filter is not None:
        vision.active_color_filter = cfg.color_filter
    if cfg.auto_scan is not None:
        ACTIVE_SESSION["auto_scan_enabled"] = cfg.auto_scan
    return {"ok": True, "session": ACTIVE_SESSION, "filter": vision.active_color_filter}


@app.post("/api/etiqueta/generar")
def crear_etiqueta_qr(data: InspeccionCajaIn):
    conn = get_connection()
    cur = conn.cursor()
    cp = cur.execute(
        """
        SELECT cp.*, p.NOMBRE_PRODUCTO, pr.NOMBRE_PROVEEDOR
        FROM color_producto cp
        JOIN producto p ON p.ID_PRODUCTO = cp.ID_PRODUCTO
        JOIN proveedor pr ON pr.ID_PROVEEDOR = cp.ID_PROVEEDOR
        WHERE cp.ID_COLOR_PRODUCTO = ?
        """,
        (data.id_color_producto,),
    ).fetchone()
    conn.close()

    if not cp:
        raise HTTPException(status_code=404, detail="Color/Producto no encontrado")

    codigo_caja = f"CJ-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    if data.estado_inspeccion == "DANADO":
        ruta = "SERVO_1_DANADA"
    elif data.estado_inspeccion == "INCORRECTO":
        ruta = "SERVO_2_NO_ESPERADO"
    else:
        ruta = "NINGUNO (NORMAL)"

    qr_payload = f"{codigo_caja}|{cp['NOMBRE_COLOR']}|{data.estado_inspeccion}"

    qr = qrcode.QRCode(box_size=6, border=2)
    qr.add_data(qr_payload)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    qr_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

    return {
        "codigo_caja": codigo_caja,
        "qr_payload": qr_payload,
        "qr_base64": qr_b64,
        "color": cp["NOMBRE_COLOR"],
        "hex": cp["CODIGO_HEX"],
        "producto": cp["NOMBRE_PRODUCTO"],
        "proveedor": cp["NOMBRE_PROVEEDOR"],
        "estado": data.estado_inspeccion,
        "cantidad_real": data.cantidad_real,
        "ruta": ruta,
    }


@app.post("/api/tickets/random")
def crear_tickets_random(cantidad: int = 5):
    tickets = generar_lote_tickets(cantidad=cantidad)
    conn = get_connection()
    cur = conn.cursor()
    for t in tickets:
        cur.execute(
            """
            INSERT OR IGNORE INTO tickets_simulados
            (TICKET_ID, PO_ID, SUPPLIER, SKU, UNIT, ORDERED_QTY, RECEIVED_QTY, MEASURED_QTY,
             DELTA_VS_ORDER, UNIT_COST_MXN, LOT, SCENARIO, STATUS, RECOMMENDED_ACTION, LINKED_WO, CREATED_AT)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                t["ticket_id"], t["po_id"], t["supplier"], t["sku"], t["unit"],
                t["ordered_qty"], t["received_qty"], t["measured_qty"], t["delta_vs_order"],
                t["unit_cost_mxn"], t["lot"], t["scenario"], t["status"],
                t["recommended_action"], t["linked_wo"], t["timestamp"],
            ),
        )
    conn.commit()
    conn.close()
    return {"generados": len(tickets), "tickets": tickets}


@app.post("/api/simular_paso_banda")
def simular_paso_banda(color: str, qr: str = ""):
    vision.last_trigger_time = 0
    vision.flash_until = time.time() + 1.8
    registrar_lectura_banda(color, qr)
    return {"ok": True, "session": ACTIVE_SESSION}


@app.post("/api/reset_demo")
def reset_demo():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM lectura_banda")
    cur.execute("DELETE FROM caja")
    cur.execute("DELETE FROM orden_trabajo")
    cur.execute("DELETE FROM tickets_simulados")
    cur.execute("UPDATE lote_recepcion SET CANTIDAD_CAJAS_CONTADA = 0, ID_ESTADO_LOTE = 1")
    conn.commit()
    conn.close()
    vision.servo_state = "NINGUNO"
    vision.servo_label = "REPOSO (PASA NORMAL)"
    sincronizar_conteo_lote(ACTIVE_SESSION["id_lote"])
    ACTIVE_SESSION["last_event"] = "Base operativa reiniciada."
    ACTIVE_SESSION["last_route"] = "STANDBY"
    ACTIVE_SESSION["servo_activado"] = "NINGUNO (NORMAL)"
    return {"ok": True}


app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/", response_class=HTMLResponse)
def index():
    with open("static/index.html", "r", encoding="utf-8") as f:
        return f.read()
