import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "trisomicos_bd.db"


def get_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS estado_oc (
            ID_ESTADO_OC INTEGER PRIMARY KEY,
            NOMBRE_ESTADO_OC TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS frecuencia_entrega (
            ID_FRECUENCIA INTEGER PRIMARY KEY,
            NOMBRE_FRECUENCIA TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS estado_lote (
            ID_ESTADO_LOTE INTEGER PRIMARY KEY,
            NOMBRE_ESTADO_LOTE TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS tipo_incidencia (
            ID_TIPO_INCIDENCIA INTEGER PRIMARY KEY,
            NOMBRE_TIPO_INCIDENCIA TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS estado_orden_trabajo (
            ID_ESTADO_ORDEN_TRABAJO INTEGER PRIMARY KEY,
            NOMBRE_ESTADO_ORDEN_TRABAJO TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS proveedor (
            ID_PROVEEDOR INTEGER PRIMARY KEY AUTOINCREMENT,
            NOMBRE_PROVEEDOR TEXT NOT NULL,
            RFC TEXT,
            CONTACTO TEXT,
            TELEFONO TEXT
        );

        CREATE TABLE IF NOT EXISTS producto (
            ID_PRODUCTO INTEGER PRIMARY KEY AUTOINCREMENT,
            CODIGO_SKU TEXT NOT NULL UNIQUE,
            NOMBRE_PRODUCTO TEXT NOT NULL,
            UNIDAD_MEDIDA TEXT NOT NULL,
            COSTO_UNITARIO REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS color_producto (
            ID_COLOR_PRODUCTO INTEGER PRIMARY KEY AUTOINCREMENT,
            ID_PRODUCTO INTEGER NOT NULL,
            ID_PROVEEDOR INTEGER NOT NULL,
            NOMBRE_COLOR TEXT NOT NULL,
            CODIGO_HEX TEXT NOT NULL,
            FOREIGN KEY (ID_PRODUCTO) REFERENCES producto(ID_PRODUCTO),
            FOREIGN KEY (ID_PROVEEDOR) REFERENCES proveedor(ID_PROVEEDOR)
        );

        CREATE TABLE IF NOT EXISTS orden_compra (
            ID_OC INTEGER PRIMARY KEY AUTOINCREMENT,
            ID_PROVEEDOR INTEGER NOT NULL,
            ID_ESTADO_OC INTEGER NOT NULL,
            ID_FRECUENCIA INTEGER NOT NULL,
            FECHA_EMISION TEXT NOT NULL,
            FOREIGN KEY (ID_PROVEEDOR) REFERENCES proveedor(ID_PROVEEDOR),
            FOREIGN KEY (ID_ESTADO_OC) REFERENCES estado_oc(ID_ESTADO_OC),
            FOREIGN KEY (ID_FRECUENCIA) REFERENCES frecuencia_entrega(ID_FRECUENCIA)
        );

        CREATE TABLE IF NOT EXISTS orden_compra_detalle (
            ID_DETALLE INTEGER PRIMARY KEY AUTOINCREMENT,
            ID_OC INTEGER NOT NULL,
            ID_PRODUCTO INTEGER NOT NULL,
            CANTIDAD_SOLICITADA INTEGER NOT NULL,
            FOREIGN KEY (ID_OC) REFERENCES orden_compra(ID_OC),
            FOREIGN KEY (ID_PRODUCTO) REFERENCES producto(ID_PRODUCTO)
        );

        CREATE TABLE IF NOT EXISTS lote_recepcion (
            ID_LOTE INTEGER PRIMARY KEY AUTOINCREMENT,
            ID_OC INTEGER NOT NULL,
            ID_ESTADO_LOTE INTEGER NOT NULL,
            CANTIDAD_CAJAS_ESPERADA INTEGER NOT NULL,
            CANTIDAD_CAJAS_CONTADA INTEGER NOT NULL DEFAULT 0,
            FECHA_RECEPCION TEXT NOT NULL,
            FOREIGN KEY (ID_OC) REFERENCES orden_compra(ID_OC),
            FOREIGN KEY (ID_ESTADO_LOTE) REFERENCES estado_lote(ID_ESTADO_LOTE)
        );

        CREATE TABLE IF NOT EXISTS caja (
            ID_CAJA INTEGER PRIMARY KEY AUTOINCREMENT,
            CODIGO_CAJA TEXT NOT NULL UNIQUE,
            ID_LOTE INTEGER NOT NULL,
            ID_COLOR_PRODUCTO INTEGER NOT NULL,
            ESTADO_INSPECCION TEXT NOT NULL,
            CANTIDAD_REAL INTEGER NOT NULL,
            RUTA_ASIGNADA TEXT NOT NULL,
            LEIDA INTEGER NOT NULL DEFAULT 0,
            FECHA_LECTURA_BANDA TEXT,
            FOREIGN KEY (ID_LOTE) REFERENCES lote_recepcion(ID_LOTE),
            FOREIGN KEY (ID_COLOR_PRODUCTO) REFERENCES color_producto(ID_COLOR_PRODUCTO)
        );

        CREATE TABLE IF NOT EXISTS lectura_banda (
            ID_LECTURA INTEGER PRIMARY KEY AUTOINCREMENT,
            ID_CAJA INTEGER NOT NULL,
            COLOR_DETECTADO TEXT NOT NULL,
            QR_DETECTADO TEXT,
            RUTA_ACCIONADA TEXT NOT NULL,
            TIMESTAMP_LECTURA TEXT NOT NULL,
            RESULTADO TEXT NOT NULL,
            FOREIGN KEY (ID_CAJA) REFERENCES caja(ID_CAJA)
        );

        CREATE TABLE IF NOT EXISTS orden_trabajo (
            ID_OT INTEGER PRIMARY KEY AUTOINCREMENT,
            ID_LOTE INTEGER NOT NULL,
            ID_TIPO_INCIDENCIA INTEGER NOT NULL,
            ID_ESTADO_ORDEN_TRABAJO INTEGER NOT NULL,
            DESCRIPCION TEXT NOT NULL,
            FECHA_CREACION TEXT NOT NULL,
            FOREIGN KEY (ID_LOTE) REFERENCES lote_recepcion(ID_LOTE),
            FOREIGN KEY (ID_TIPO_INCIDENCIA) REFERENCES tipo_incidencia(ID_TIPO_INCIDENCIA),
            FOREIGN KEY (ID_ESTADO_ORDEN_TRABAJO) REFERENCES estado_orden_trabajo(ID_ESTADO_ORDEN_TRABAJO)
        );

        CREATE TABLE IF NOT EXISTS tickets_simulados (
            ID_TICKET INTEGER PRIMARY KEY AUTOINCREMENT,
            TICKET_ID TEXT NOT NULL UNIQUE,
            PO_ID TEXT NOT NULL,
            SUPPLIER TEXT NOT NULL,
            SKU TEXT NOT NULL,
            UNIT TEXT NOT NULL,
            ORDERED_QTY INTEGER NOT NULL,
            RECEIVED_QTY INTEGER NOT NULL,
            MEASURED_QTY INTEGER NOT NULL,
            DELTA_VS_ORDER INTEGER NOT NULL,
            UNIT_COST_MXN REAL NOT NULL,
            LOT TEXT NOT NULL,
            SCENARIO TEXT NOT NULL,
            STATUS TEXT NOT NULL,
            RECOMMENDED_ACTION TEXT NOT NULL,
            LINKED_WO TEXT,
            CREATED_AT TEXT NOT NULL
        );
        """
    )

    cur.executemany(
        "INSERT OR IGNORE INTO estado_oc VALUES (?, ?)",
        [(1, "EMITIDA"), (2, "EN_RECEPCION"), (3, "CERRADA")],
    )
    cur.executemany(
        "INSERT OR IGNORE INTO frecuencia_entrega VALUES (?, ?)",
        [(1, "UNICA"), (2, "SEMANAL"), (3, "QUINCENAL")],
    )
    cur.executemany(
        "INSERT OR IGNORE INTO estado_lote VALUES (?, ?)",
        [(1, "EN_RECEPCION"), (2, "COMPLETO"), (3, "INCOMPLETO"), (4, "EXCEDENTE")],
    )
    cur.executemany(
        "INSERT OR IGNORE INTO tipo_incidencia VALUES (?, ?)",
        [(1, "CAJA_DANADA_O_INCORRECTA"), (2, "FALTANTE"), (3, "NO_COINCIDE_OC"), (4, "EXCEDENTE")],
    )
    cur.executemany(
        "INSERT OR IGNORE INTO estado_orden_trabajo VALUES (?, ?)",
        [(1, "ABIERTA"), (2, "EN_REVISION"), (3, "RESUELTA")],
    )

    if cur.execute("SELECT COUNT(*) FROM proveedor").fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO proveedor (ID_PROVEEDOR, NOMBRE_PROVEEDOR, RFC, CONTACTO, TELEFONO) VALUES (?, ?, ?, ?, ?)",
            [
                (1, "Aceros del Norte SA", "ANO920312H11", "Carlos Mendez", "229-110-2030"),
                (2, "Plasticos Industriales MX", "PIM880514K90", "Laura Gomez", "229-440-8899"),
                (3, "ElectroComponentes Veracruz", "ECV010922M45", "Luis Ortega", "229-778-1122"),
            ],
        )

    if cur.execute("SELECT COUNT(*) FROM producto").fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO producto (ID_PRODUCTO, CODIGO_SKU, NOMBRE_PRODUCTO, UNIDAD_MEDIDA, COSTO_UNITARIO) VALUES (?, ?, ?, ?, ?)",
            [
                (1, "TORN_M6X20", "Tornillo Hexagonal M6x20", "CAJA", 450.0),
                (2, "VALV_PVC_2", "Valvula PVC 2 Pulgadas", "CAJA", 780.0),
                (3, "CABLE_THW_12", "Rollo Cable THW Cal 12", "ROLLO", 1120.0),
                (4, "SENSOR_IND_12V", "Sensor Inductivo 12V NPN", "CAJA", 1650.0),
                (5, "CONECTOR_RJ45", "Caja Conectores RJ45 Cat6", "CAJA", 320.0),
            ],
        )

    if cur.execute("SELECT COUNT(*) FROM color_producto").fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO color_producto (ID_COLOR_PRODUCTO, ID_PRODUCTO, ID_PROVEEDOR, NOMBRE_COLOR, CODIGO_HEX) VALUES (?, ?, ?, ?, ?)",
            [
                (1, 1, 1, "AZUL", "#2563EB"),
                (2, 2, 2, "NARANJA", "#F97316"),
                (3, 3, 3, "VERDE", "#16A34A"),
                (4, 4, 3, "AMARILLO", "#EAB308"),
                (5, 5, 1, "MORADO", "#9333EA"),
            ],
        )

    if cur.execute("SELECT COUNT(*) FROM orden_compra").fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO orden_compra (ID_OC, ID_PROVEEDOR, ID_ESTADO_OC, ID_FRECUENCIA, FECHA_EMISION) VALUES (?, ?, ?, ?, ?)",
            [
                (1, 1, 2, 2, "2026-11-25"),
                (2, 2, 2, 1, "2026-11-25"),
                (3, 3, 2, 2, "2026-11-25"),
            ],
        )
        cur.executemany(
            "INSERT INTO orden_compra_detalle (ID_OC, ID_PRODUCTO, CANTIDAD_SOLICITADA) VALUES (?, ?, ?)",
            [
                (1, 1, 5),
                (2, 2, 4),
                (3, 3, 6),
            ],
        )
        cur.executemany(
            "INSERT INTO lote_recepcion (ID_LOTE, ID_OC, ID_ESTADO_LOTE, CANTIDAD_CAJAS_ESPERADA, CANTIDAD_CAJAS_CONTADA, FECHA_RECEPCION) VALUES (?, ?, ?, ?, ?, ?)",
            [
                (1, 1, 1, 5, 0, "2026-11-25"),
                (2, 2, 1, 4, 0, "2026-11-25"),
                (3, 3, 1, 6, 0, "2026-11-25"),
            ],
        )

    conn.commit()
    conn.close()
