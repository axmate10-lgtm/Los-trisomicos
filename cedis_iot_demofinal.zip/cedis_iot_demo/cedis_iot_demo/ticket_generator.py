import random
from datetime import datetime

CATALOGO_SIM = [
    {"po_id": "OC-101", "supplier": "Aceros del Norte SA", "sku": "TORN_M6X20", "unit": "CAJA", "cost": 450.0, "lot": "LOTE-01"},
    {"po_id": "OC-102", "supplier": "Plasticos Industriales MX", "sku": "VALV_PVC_2", "unit": "CAJA", "cost": 780.0, "lot": "LOTE-02"},
    {"po_id": "OC-103", "supplier": "ElectroComponentes Veracruz", "sku": "CABLE_THW_12", "unit": "ROLLO", "cost": 1120.0, "lot": "LOTE-03"},
]

ESCENARIOS = [
    ("CORRECTO", "APROBADO", "Ingresar a ubicacion A-01"),
    ("INCORRECTO", "RETENIDO_SERVO_2", "Desviar con Servo 2 y abrir incidencia"),
    ("DANADO", "RETENIDO_SERVO_1", "Desviar con Servo 1 a cuarentena"),
    ("DIFIERE_PARCIAL", "INCIDENCIA_FALTANTE", "Notificar faltante a Compras"),
    ("DIFIERE_EXCEDENTE", "INCIDENCIA_EXCEDENTE", "Retener excedente en muelle"),
]


def generar_lote_tickets(cantidad=5):
    resultados = []
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for _ in range(cantidad):
        item = random.choice(CATALOGO_SIM)
        scenario, status, action = random.choice(ESCENARIOS)
        ordered = random.randint(4, 10)
        if scenario == "CORRECTO":
            received = ordered
            measured = ordered
        elif scenario == "DIFIERE_PARCIAL":
            received = max(1, ordered - random.randint(1, 3))
            measured = received
        elif scenario == "DIFIERE_EXCEDENTE":
            received = ordered + random.randint(1, 3)
            measured = received
        else:
            received = ordered
            measured = ordered

        delta = measured - ordered
        tid = f"TCK-{datetime.now().strftime('%H%M%S')}-{random.randint(100, 999)}"
        wo = None if scenario == "CORRECTO" else f"OT-{random.randint(1000, 9999)}"

        resultados.append(
            {
                "ticket_id": tid,
                "po_id": item["po_id"],
                "supplier": item["supplier"],
                "sku": item["sku"],
                "unit": item["unit"],
                "ordered_qty": ordered,
                "received_qty": received,
                "measured_qty": measured,
                "delta_vs_order": delta,
                "unit_cost_mxn": item["cost"],
                "lot": item["lot"],
                "scenario": scenario,
                "status": status,
                "recommended_action": action,
                "linked_wo": wo,
                "timestamp": now,
            }
        )
    return resultados
