import threading
import time
import cv2
import numpy as np

COLOR_RANGES_HSV = {
    "AZUL":     {"lower": np.array([92, 65, 65]),   "upper": np.array([122, 255, 255]), "bgr": (255, 120, 0)},
    "MORADO":   {"lower": np.array([123, 55, 50]),  "upper": np.array([158, 255, 255]), "bgr": (180, 50, 140)},
    "VERDE":    {"lower": np.array([42, 55, 60]),   "upper": np.array([88, 255, 255]),  "bgr": (60, 180, 40)},
    "AMARILLO": {"lower": np.array([22, 70, 80]),   "upper": np.array([38, 255, 255]),  "bgr": (0, 220, 255)},
    "NARANJA":  {"lower": np.array([6, 75, 85]),    "upper": np.array([21, 255, 255]),  "bgr": (0, 130, 255)},
}


class VisionSystem:
    def __init__(self, on_detection_callback=None):
        self.cap = None
        self.running = False
        self.lock = threading.Lock()
        self.raw_jpeg = None
        self.filtered_jpeg = None
        self.on_detection_callback = on_detection_callback
        self.qr_detector = cv2.QRCodeDetector()

        self.current_color = "NINGUNO"
        self.current_qr = "SIN_QR"
        self.active_color_filter = "TODOS"
        self.last_trigger_time = 0.0
        self.cooldown_seconds = 2.8

        self.servo_state = "NINGUNO"
        self.servo_label = "REPOSO (PASA NORMAL)"
        self.lote_conteo_texto = "0 / 0"
        self.flash_until = 0.0

    def start(self, camera_index=0):
        if self.running:
            return
        self.cap = (
            cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
            if hasattr(cv2, "CAP_DSHOW")
            else cv2.VideoCapture(camera_index)
        )
        if not self.cap.isOpened():
            self.cap = cv2.VideoCapture(camera_index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self.running = False
        if self.cap:
            self.cap.release()

    def _make_placeholder(self, text):
        img = np.zeros((360, 480, 3), dtype=np.uint8)
        cv2.putText(img, text, (30, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 200), 2)
        _, buf = cv2.imencode(".jpg", img)
        return buf.tobytes()

    def _draw_red_grids(self, img, now):
        h, w = img.shape[:2]

        # 1. Cuadricula Roja Central: ZONA DE DISPARO / PASO DE CAJA
        x1, y1 = int(w * 0.30), int(h * 0.28)
        x2, y2 = int(w * 0.70), int(h * 0.78)

        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 0, 255), 2)
        mid_x = (x1 + x2) // 2
        mid_y = (y1 + y2) // 2
        cv2.line(img, (mid_x, y1), (mid_x, y2), (0, 0, 180), 1)
        cv2.line(img, (x1, mid_y), (x2, mid_y), (0, 0, 180), 1)
        cv2.putText(img, "ZONA DISPARO BANDA", (x1 + 8, y1 - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (0, 0, 255), 2)

        # 2. Cuadricula Roja Izquierda: SERVO 1 (CAJA DANADA)
        s1_x1, s1_y1, s1_x2, s1_y2 = 12, int(h * 0.32), int(w * 0.26), int(h * 0.74)
        s1_active = (self.servo_state == "SERVO_1") and (now < self.flash_until)
        if s1_active:
            overlay = img.copy()
            cv2.rectangle(overlay, (s1_x1, s1_y1), (s1_x2, s1_y2), (0, 0, 255), -1)
            cv2.addWeighted(overlay, 0.45, img, 0.55, 0, img)
        cv2.rectangle(img, (s1_x1, s1_y1), (s1_x2, s1_y2), (0, 0, 255), 2)
        cv2.putText(img, "SERVO 1", (s1_x1 + 12, s1_y1 + 28), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255) if s1_active else (0, 0, 255), 2)
        cv2.putText(img, "DANADA", (s1_x1 + 12, s1_y1 + 52), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (200, 200, 255), 1)
        cv2.putText(img, "ACTIVO!" if s1_active else "OFF", (s1_x1 + 12, s1_y2 - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255) if s1_active else (120, 120, 120), 2)

        # 3. Cuadricula Roja Derecha: SERVO 2 (PRODUCTO NO ESPERADO / INCORRECTO)
        s2_x1, s2_y1, s2_x2, s2_y2 = int(w * 0.74), int(h * 0.32), w - 12, int(h * 0.74)
        s2_active = (self.servo_state == "SERVO_2") and (now < self.flash_until)
        if s2_active:
            overlay = img.copy()
            cv2.rectangle(overlay, (s2_x1, s2_y1), (s2_x2, s2_y2), (0, 0, 255), -1)
            cv2.addWeighted(overlay, 0.45, img, 0.55, 0, img)
        cv2.rectangle(img, (s2_x1, s2_y1), (s2_x2, s2_y2), (0, 0, 255), 2)
        cv2.putText(img, "SERVO 2", (s2_x1 + 12, s2_y1 + 28), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255) if s2_active else (0, 0, 255), 2)
        cv2.putText(img, "NO ESPERADO", (s2_x1 + 8, s2_y1 + 52), cv2.FONT_HERSHEY_SIMPLEX, 0.43, (200, 200, 255), 1)
        cv2.putText(img, "ACTIVO!" if s2_active else "OFF", (s2_x1 + 12, s2_y2 - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255) if s2_active else (120, 120, 120), 2)

        # 4. Barra inferior de estado de paso, servo y conteo
        cv2.rectangle(img, (0, h - 42), (w, h), (15, 23, 42), -1)
        paso_color = (0, 255, 0) if now < self.flash_until else (0, 220, 255)
        texto_paso = ">>> CAJA REGISTRADA - PUEDE PASAR <<<" if now < self.flash_until else "COLOCA ETIQUETA EN CUADRICULA CENTRAL"
        cv2.putText(img, texto_paso, (10, h - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.50, paso_color, 2)
        cv2.putText(img, f"CONTEO: {self.lote_conteo_texto}", (w - 175, h - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (255, 255, 255), 2)

    def _loop(self):
        kernel = np.ones((5, 5), np.uint8)
        while self.running:
            if not self.cap or not self.cap.isOpened():
                placeholder = self._make_placeholder("Camara no disponible")
                with self.lock:
                    self.raw_jpeg = placeholder
                    self.filtered_jpeg = placeholder
                time.sleep(0.5)
                continue

            ret, frame = self.cap.read()
            if not ret:
                time.sleep(0.05)
                continue

            frame = cv2.flip(frame, 1)
            h, w = frame.shape[:2]
            raw_display = frame.copy()
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

            roi_x1, roi_y1 = int(w * 0.30), int(h * 0.28)
            roi_x2, roi_y2 = int(w * 0.70), int(h * 0.78)

            qr_text = ""
            try:
                data, bbox, _ = self.qr_detector.detectAndDecode(frame)
                if data:
                    qr_text = data.strip()
                    if bbox is not None:
                        pts = bbox.astype(int).reshape(-1, 2)
                        cv2.polylines(raw_display, [pts], True, (0, 255, 0), 3)
            except Exception:
                pass

            combined_mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
            detected_color = "NINGUNO"
            in_trigger_zone = False
            max_area = 2200

            colors_to_scan = (
                COLOR_RANGES_HSV.items()
                if self.active_color_filter == "TODOS"
                else [(self.active_color_filter, COLOR_RANGES_HSV[self.active_color_filter])]
            )

            for color_name, cfg in colors_to_scan:
                mask = cv2.inRange(hsv, cfg["lower"], cfg["upper"])
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
                mask = cv2.morphologyEx(mask, cv2.MORPH_DILATE, kernel)
                combined_mask = cv2.bitwise_or(combined_mask, mask)

                contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for cnt in contours:
                    area = cv2.contourArea(cnt)
                    if area > max_area:
                        x, y, bw, bh = cv2.boundingRect(cnt)
                        cx, cy = x + bw // 2, y + bh // 2
                        dentro_roi = (roi_x1 <= cx <= roi_x2) and (roi_y1 <= cy <= roi_y2)
                        if dentro_roi:
                            max_area = area
                            detected_color = color_name
                            in_trigger_zone = True

                        cv2.rectangle(raw_display, (x, y), (x + bw, y + bh), cfg["bgr"], 3 if dentro_roi else 1)
                        cv2.circle(raw_display, (cx, cy), 5, (0, 0, 255) if dentro_roi else (200, 200, 200), -1)
                        cv2.putText(
                            raw_display,
                            f"{color_name}" + (" [EN ZONA]" if dentro_roi else ""),
                            (x, max(20, y - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.55,
                            cfg["bgr"],
                            2,
                        )

            filtered_display = cv2.bitwise_and(frame, frame, mask=combined_mask)
            now = time.time()
            self._draw_red_grids(filtered_display, now)
            cv2.rectangle(raw_display, (roi_x1, roi_y1), (roi_x2, roi_y2), (0, 0, 255), 2)

            cv2.putText(
                filtered_display,
                f"FILTRO [{self.active_color_filter}] | COLOR: {detected_color} | {self.servo_label}",
                (10, 24),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.50,
                (0, 255, 255),
                2,
            )

            self.current_color = detected_color
            self.current_qr = qr_text if qr_text else "SIN_QR"

            if ((in_trigger_zone and detected_color != "NINGUNO") or qr_text) and (
                now - self.last_trigger_time > self.cooldown_seconds
            ):
                self.last_trigger_time = now
                self.flash_until = now + 1.8
                if self.on_detection_callback:
                    self.on_detection_callback(detected_color, qr_text)

            _, buf_raw = cv2.imencode(".jpg", raw_display, [cv2.IMWRITE_JPEG_QUALITY, 80])
            _, buf_flt = cv2.imencode(".jpg", filtered_display, [cv2.IMWRITE_JPEG_QUALITY, 80])

            with self.lock:
                self.raw_jpeg = buf_raw.tobytes()
                self.filtered_jpeg = buf_flt.tobytes()

            time.sleep(0.03)
