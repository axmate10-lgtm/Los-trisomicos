import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "trisomicos_bd.db"


def get_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.executescript('''
    CREATE TABLE IF NOT EXISTS proveedor (
        ID_PROVEEDOR INTEGER PRIMARY KEY AUTOINCREMENT,
        NOMBRE_PROVEEDOR TEXT NOT NULL,
        CONTACTO TEXT,
        TELEFONO TEXT,
        ACTIVO INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS producto (
        ID_PRODUCTO INTEGER PRIMARY KEY AUTOINCREMENT,
        NOMBRE_PRODUCTO TEXT NOT NULL,
        UNIDAD_MEDIDA TEXT NOT NULL,
        PIEZAS_POR_CAJA_ESTANDAR INTEGER NOT NULL,
        ACTIVO INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS estado_oc (
        ID_ESTADO_OC INTEGER PRIMARY KEY AUTOINCREMENT,
        NOMBRE_ESTADO_OC TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS frecuencia_entrega (
        ID_FRECUENCIA INTEGER PRIMARY KEY AUTOINCREMENT,
        NOMBRE_FRECUENCIA TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS estado_lote (
        ID_ESTADO_LOTE INTEGER PRIMARY KEY AUTOINCREMENT,
        NOMBRE_ESTADO_LOTE TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tipo_incidencia (
        ID_TIPO_INCIDENCIA INTEGER PRIMARY KEY AUTOINCREMENT,
        NOMBRE_TIPO_INCIDENCIA TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS estado_orden_trabajo (
        ID_ESTADO_ORDEN_TRABAJO INTEGER PRIMARY KEY AUTOINCREMENT,
        NOMBRE_ESTADO_ORDEN_TRABAJO TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS usuario (
        ID_USUARIO INTEGER PRIMARY KEY AUTOINCREMENT,
        NOMBRE TEXT NOT NULL,
        ROL TEXT NOT NULL,
        ACTIVO INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS color_producto (
        ID_COLOR_PRODUCTO INTEGER PRIMARY KEY AUTOINCREMENT,
        ID_PRODUCTO INTEGER NOT NULL,
        ID_PROVEEDOR INTEGER NOT NULL,
        NOMBRE_COLOR TEXT NOT NULL,
        CODIGO_HEX TEXT NOT NULL,
        FOREIGN KEY (ID_PRODUCTO) REFERENCES producto(ID_PRODUCTO),
        FOREIGN KEY (ID_PROVEEDOR) REFERENCES proveedor(ID_PROVEEDOR)
    );

    CREATE TABLE IF NOT EXISTS orden_compra (
        ID_OC INTEGER PRIMARY KEY AUTOINCREMENT,
        ID_PROVEEDOR INTEGER NOT NULL,
        ID_ESTADO_OC INTEGER NOT NULL,
        ID_FRECUENCIA INTEGER NOT NULL,
        FECHA_ALTA TEXT NOT NULL,
        FECHA_PROXIMA_ENTREGA TEXT,
        FOREIGN KEY (ID_PROVEEDOR) REFERENCES proveedor(ID_PROVEEDOR),
        FOREIGN KEY (ID_ESTADO_OC) REFERENCES estado_oc(ID_ESTADO_OC),
        FOREIGN KEY (ID_FRECUENCIA) REFERENCES frecuencia_entrega(ID_FRECUENCIA)
    );

    CREATE TABLE IF NOT EXISTS orden_compra_detalle (
        ID_OC_DETALLE INTEGER PRIMARY KEY AUTOINCREMENT,
        ID_OC INTEGER NOT NULL,
        ID_PRODUCTO INTEGER NOT NULL,
        CANTIDAD_CAJAS_ESPERADA INTEGER NOT NULL,
        PIEZAS_POR_CAJA INTEGER NOT NULL,
        FOREIGN KEY (ID_OC) REFERENCES orden_compra(ID_OC),
        FOREIGN KEY (ID_PRODUCTO) REFERENCES producto(ID_PRODUCTO)
    );

    CREATE TABLE IF NOT EXISTS lote_recepcion (
        ID_LOTE INTEGER PRIMARY KEY AUTOINCREMENT,
        ID_OC INTEGER NOT NULL,
        ID_ESTADO_LOTE INTEGER NOT NULL,
        FECHA_RECEPCION TEXT NOT NULL,
        CANTIDAD_CAJAS_ESPERADA INTEGER NOT NULL,
        CANTIDAD_CAJAS_CONTADA INTEGER DEFAULT 0,
        ID_USUARIO_RECEPCION INTEGER NOT NULL,
        FOREIGN KEY (ID_OC) REFERENCES orden_compra(ID_OC),
        FOREIGN KEY (ID_ESTADO_LOTE) REFERENCES estado_lote(ID_ESTADO_LOTE),
        FOREIGN KEY (ID_USUARIO_RECEPCION) REFERENCES usuario(ID_USUARIO)
    );

    CREATE TABLE IF NOT EXISTS caja (
        ID_CAJA INTEGER PRIMARY KEY AUTOINCREMENT,
        CODIGO_CAJA TEXT UNIQUE,
        ID_LOTE INTEGER NOT NULL,
        ID_COLOR_PRODUCTO INTEGER NOT NULL,
        ESTADO_INSPECCION TEXT DEFAULT 'CORRECTO',
        CANTIDAD_REAL INTEGER DEFAULT 0,
        RUTA_ASIGNADA TEXT DEFAULT 'ALMACEN_OK',
        LEIDA INTEGER DEFAULT 0,
        FECHA_LECTURA_BANDA TEXT,
        FOREIGN KEY (ID_LOTE) REFERENCES lote_recepcion(ID_LOTE),
        FOREIGN KEY (ID_COLOR_PRODUCTO) REFERENCES color_producto(ID_COLOR_PRODUCTO)
    );

    CREATE TABLE IF NOT EXISTS lectura_banda (
        ID_LECTURA INTEGER PRIMARY KEY AUTOINCREMENT,
        ID_CAJA INTEGER NOT NULL,
        COLOR_DETECTADO TEXT,
        QR_DETECTADO TEXT,
        RUTA_ACCIONADA TEXT,
        TIMESTAMP_LECTURA TEXT NOT NULL,
        RESULTADO TEXT NOT NULL,
        FOREIGN KEY (ID_CAJA) REFERENCES caja(ID_CAJA)
    );

    CREATE TABLE IF NOT EXISTS orden_trabajo (
        ID_OT INTEGER PRIMARY KEY AUTOINCREMENT,
        ID_LOTE INTEGER NOT NULL,
        ID_TIPO_INCIDENCIA INTEGER NOT NULL,
        ID_ESTADO_ORDEN_TRABAJO INTEGER NOT NULL,
        DESCRIPCION TEXT,
        FECHA_CREACION TEXT NOT NULL,
        FOREIGN KEY (ID_LOTE) REFERENCES lote_recepcion(ID_LOTE),
        FOREIGN KEY (ID_TIPO_INCIDENCIA) REFERENCES tipo_incidencia(ID_TIPO_INCIDENCIA),
        FOREIGN KEY (ID_ESTADO_ORDEN_TRABAJO) REFERENCES estado_orden_trabajo(ID_ESTADO_ORDEN_TRABAJO)
    );

    CREATE TABLE IF NOT EXISTS tickets_simulados (
        ID_TICKET INTEGER PRIMARY KEY AUTOINCREMENT,
        TICKET_ID TEXT UNIQUE NOT NULL,
        PO_ID TEXT NOT NULL,
        SUPPLIER TEXT NOT NULL,
        SKU TEXT NOT NULL,
        UNIT TEXT NOT NULL,
        ORDERED_QTY INTEGER NOT NULL,
        RECEIVED_QTY INTEGER NOT NULL,
        MEASURED_QTY INTEGER NOT NULL,
        DELTA_VS_ORDER INTEGER NOT NULL,
        UNIT_COST_MXN REAL,
        LOT TEXT NOT NULL,
        SCENARIO TEXT NOT NULL,
        STATUS TEXT NOT NULL,
        RECOMMENDED_ACTION TEXT NOT NULL,
        LINKED_WO TEXT NOT NULL,
        CREATED_AT TEXT NOT NULL
    );
    ''')

    # Verificar si ya existen datos semilla
    count = cur.execute("SELECT COUNT(*) FROM proveedor").fetchone()[0]
    if count == 0:
        cur.executemany(
            "INSERT INTO proveedor (ID_PROVEEDOR, NOMBRE_PROVEEDOR, CONTACTO, TELEFONO, ACTIVO) VALUES (?, ?, ?, ?, ?)",
            [
                (1, "PROV_NORTE", "LUIS HERNANDEZ", "2281234567", 1),
                (2, "PROV_GOLFO", "ANA MARTINEZ", "2297654321", 1),
                (3, "PROV_IND_MX", "JORGE RAMIREZ", "2299988776", 1),
            ],
        )

        cur.executemany(
            "INSERT INTO producto (ID_PRODUCTO, NOMBRE_PRODUCTO, UNIDAD_MEDIDA, PIEZAS_POR_CAJA_ESTANDAR, ACTIVO) VALUES (?, ?, ?, ?, ?)",
            [
                (1, "TORN_M6X20", "PCS", 500, 1),
                (2, "ROD_608ZZ", "PCS", 100, 1),
                (3, "CABLE_18AWG", "M", 50, 1),
                (4, "SENSOR_IND_M12", "PCS", 20, 1),
            ],
        )

        cur.executemany(
            "INSERT INTO estado_oc (ID_ESTADO_OC, NOMBRE_ESTADO_OC) VALUES (?, ?)",
            [(1, "ACTIVA"), (2, "PAUSADA"), (3, "CANCELADA"), (4, "COMPLETADA")],
        )

        cur.executemany(
            "INSERT INTO frecuencia_entrega (ID_FRECUENCIA, NOMBRE_FRECUENCIA) VALUES (?, ?)",
            [(1, "DIARIA"), (2, "SEMANAL"), (3, "QUINCENAL"), (4, "MENSUAL"), (5, "UNICA")],
        )

        cur.executemany(
            "INSERT INTO estado_lote (ID_ESTADO_LOTE, NOMBRE_ESTADO_LOTE) VALUES (?, ?)",
            [(1, "EN_RECEPCION"), (2, "COMPLETO"), (3, "INCOMPLETO"), (4, "EXCEDENTE")],
        )

        cur.executemany(
            "INSERT INTO tipo_incidencia (ID_TIPO_INCIDENCIA, NOMBRE_TIPO_INCIDENCIA) VALUES (?, ?)",
            [
                (1, "REVISION_CAJA_RETENIDA"),
                (2, "COMUNICACION_PROVEEDOR"),
                (3, "LOTE_INCOMPLETO"),
                (4, "LOTE_EXCEDENTE"),
                (5, "CAJA_SIN_LECTURA"),
            ],
        )

        cur.executemany(
            "INSERT INTO estado_orden_trabajo (ID_ESTADO_ORDEN_TRABAJO, NOMBRE_ESTADO_ORDEN_TRABAJO) VALUES (?, ?)",
            [(1, "PENDIENTE"), (2, "EN_PROCESO"), (3, "RESUELTA")],
        )

        cur.executemany(
            "INSERT INTO usuario (ID_USUARIO, NOMBRE, ROL, ACTIVO) VALUES (?, ?, ?, ?)",
            [(1, "MARIA LOPEZ", "ALMACENISTA", 1), (2, "CARLOS DIAZ", "SUPERVISOR", 1)],
        )

        cur.executemany(
            "INSERT INTO color_producto (ID_COLOR_PRODUCTO, ID_PRODUCTO, ID_PROVEEDOR, NOMBRE_COLOR, CODIGO_HEX) VALUES (?, ?, ?, ?, ?)",
            [
                (1, 1, 1, "AZUL", "#0057FF"),
                (2, 2, 2, "NARANJA", "#FF7A00"),
                (3, 3, 3, "VERDE", "#1FA23A"),
                (4, 4, 1, "AMARILLO", "#FFD400"),
                (5, 1, 2, "MORADO", "#7A1FA2"),
            ],
        )

        cur.executemany(
            "INSERT INTO orden_compra (ID_OC, ID_PROVEEDOR, ID_ESTADO_OC, ID_FRECUENCIA, FECHA_ALTA, FECHA_PROXIMA_ENTREGA) VALUES (?, ?, ?, ?, ?, ?)",
            [
                (1, 1, 1, 2, "2026-11-01", "2026-11-08"),
                (2, 2, 1, 2, "2026-11-01", "2026-11-08"),
                (3, 3, 1, 4, "2026-11-01", "2026-12-01"),
                (4, 1, 1, 2, "2026-11-01", "2026-11-08"),
                (5, 2, 1, 5, "2026-11-01", None),
            ],
        )

        cur.executemany(
            "INSERT INTO orden_compra_detalle (ID_OC_DETALLE, ID_OC, ID_PRODUCTO, CANTIDAD_CAJAS_ESPERADA, PIEZAS_POR_CAJA) VALUES (?, ?, ?, ?, ?)",
            [
                (1, 1, 1, 5, 500),
                (2, 2, 2, 8, 100),
                (3, 3, 3, 6, 50),
                (4, 4, 4, 7, 20),
                (5, 5, 1, 4, 500),
            ],
        )

        cur.executemany(
            "INSERT INTO lote_recepcion (ID_LOTE, ID_OC, ID_ESTADO_LOTE, FECHA_RECEPCION, CANTIDAD_CAJAS_ESPERADA, CANTIDAD_CAJAS_CONTADA, ID_USUARIO_RECEPCION) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                (1, 1, 1, "2026-11-10 09:00:00", 5, 0, 1),
                (2, 2, 1, "2026-11-10 09:30:00", 8, 0, 1),
                (3, 3, 1, "2026-11-10 10:00:00", 6, 0, 1),
                (4, 4, 1, "2026-11-10 10:30:00", 7, 0, 1),
                (5, 5, 1, "2026-11-10 11:00:00", 4, 0, 1),
            ],
        )

    conn.commit()
    conn.close()
