import random
from datetime import datetime, timezone
from typing import Dict, List, Optional

CATALOGO_SKUS = [
    {"sku": "TORN-M6X20", "unit": "pcs", "cost": 1.50, "wo": "WO-502"},
    {"sku": "ROD-608ZZ", "unit": "pcs", "cost": 28.00, "wo": "WO-505"},
    {"sku": "CABLE-18AWG", "unit": "m", "cost": 6.20, "wo": "WO-509"},
    {"sku": "SENSOR-IND-M12", "unit": "pcs", "cost": 145.00, "wo": "WO-512"},
]

PROVEEDORES = ["PROV-NORTE", "PROV-GOLFO", "PROV-IND-MX"]


def generar_ticket_prueba(
    indice: int,
    escenario_forzado: Optional[str] = None,
    seed: Optional[int] = None,
) -> Dict:
    rng = random.Random(seed) if seed is not None else random
    item = rng.choice(CATALOGO_SKUS)
    ordered_qty = rng.choice([20, 50, 100, 150, 200])

    escenarios = [
        "CORRECTO",
        "INCORRECTO",
        "DANADO",
        "DIFIERE_PARCIAL",
        "DIFIERE_EXCEDENTE",
    ]
    escenario = escenario_forzado or rng.choice(escenarios)

    received_qty = ordered_qty
    measured_qty = ordered_qty
    unit_cost = item["cost"]
    lot = f"LOT-{rng.randint(100, 999)}"
    status = "CORRECTO"
    action = "APROBAR_RECEPCION_Y_ALMACENAR"

    if escenario == "INCORRECTO":
        delta_fisico = rng.choice([-1, 1]) * max(1, int(ordered_qty * rng.uniform(0.15, 0.40)))
        measured_qty = max(0, received_qty + delta_fisico)
        status = "INCORRECTO"
        action = "DESVIAR_A_RETENCION_Y_RECONTEO"

    elif escenario == "DANADO":
        status = "DANADO"
        action = "AISLAR_EN_CUARENTENA_Y_GENERAR_OT"

    elif escenario == "DIFIERE_PARCIAL":
        diff = max(1, int(ordered_qty * rng.uniform(0.10, 0.35)))
        received_qty = ordered_qty - diff
        measured_qty = received_qty
        status = "DIFIERE_PARCIAL"
        action = "RECLAMAR_FALTANTE_Y_AJUSTAR_OT"

    elif escenario == "DIFIERE_EXCEDENTE":
        diff = max(1, int(ordered_qty * rng.uniform(0.10, 0.30)))
        received_qty = ordered_qty + diff
        measured_qty = received_qty
        status = "DIFIERE_EXCEDENTE"
        action = "ENVIAR_EXCEDENTE_A_CUARENTENA"

    delta_vs_order = measured_qty - ordered_qty

    return {
        "ticket_id": f"TCK-{rng.randint(1000,9999)}-{indice:03d}",
        "po_id": f"PO-{rng.randint(1000, 9999)}",
        "supplier": rng.choice(PROVEEDORES),
        "sku": item["sku"],
        "unit": item["unit"],
        "ordered_qty": ordered_qty,
        "received_qty": received_qty,
        "measured_qty": measured_qty,
        "delta_vs_order": delta_vs_order,
        "unit_cost_mxn": unit_cost,
        "lot": lot,
        "scenario": escenario,
        "status": status,
        "recommended_action": action,
        "linked_wo": item["wo"],
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


def generar_lote_tickets(cantidad: int = 5, seed: Optional[int] = None) -> List[Dict]:
    base_rng = random.Random(seed) if seed is not None else random
    lote = []
    for i in range(1, cantidad + 1):
        sub_seed = base_rng.randint(1, 10_000_000) if seed is not None else None
        lote.append(generar_ticket_prueba(i, seed=sub_seed))
    return lote
