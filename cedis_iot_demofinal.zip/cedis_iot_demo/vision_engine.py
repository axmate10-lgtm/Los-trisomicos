import threading
import time
from datetime import datetime
import cv2
import numpy as np

# Rangos HSV calibrados para los 5 colores del catalogo color_producto
COLOR_RANGES_HSV = {
    "AZUL":     {"lower": np.array([100, 120, 70]),  "upper": np.array([130, 255, 255]), "bgr": (255, 87, 0)},
    "NARANJA":  {"lower": np.array([8, 130, 100]),   "upper": np.array([20, 255, 255]),  "bgr": (0, 122, 255)},
    "VERDE":    {"lower": np.array([40, 80, 70]),    "upper": np.array([85, 255, 255]),  "bgr": (58, 162, 31)},
    "AMARILLO": {"lower": np.array([21, 120, 100]),  "upper": np.array([35, 255, 255]),  "bgr": (0, 212, 255)},
    "MORADO":   {"lower": np.array([131, 70, 70]),   "upper": np.array([165, 255, 255]), "bgr": (162, 31, 122)},
}


class VisionSystem:
    def __init__(self, on_detection_callback=None):
        self.cap = None
        self.running = False
        self.lock = threading.Lock()
        self.raw_jpeg = None
        self.filtered_jpeg = None
        self.on_detection_callback = on_detection_callback
        self.qr_detector = cv2.QRCodeDetector()

        # Estado en vivo para la UI
        self.current_color = "NINGUNO"
        self.current_qr = "SIN_QR"
        self.active_color_filter = "TODOS"  # Permite aislar un color o ver todos
        self.last_trigger_time = 0.0
        self.cooldown_seconds = 3.0  # Evita doble conteo de la misma caja

    def start(self, camera_index=0):
        if self.running:
            return
        self.cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW) if hasattr(cv2, "CAP_DSHOW") else cv2.VideoCapture(camera_index)
        if not self.cap.isOpened():
            self.cap = cv2.VideoCapture(camera_index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self.running = False
        if self.cap:
            self.cap.release()

    def _make_placeholder(self, text):
        img = np.zeros((360, 480, 3), dtype=np.uint8)
        cv2.putText(img, text, (30, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 200), 2)
        _, buf = cv2.imencode(".jpg", img)
        return buf.tobytes()

    def _loop(self):
        kernel = np.ones((5, 5), np.uint8)
        while self.running:
            if not self.cap or not self.cap.isOpened():
                placeholder = self._make_placeholder("Camara no disponible")
                with self.lock:
                    self.raw_jpeg = placeholder
                    self.filtered_jpeg = placeholder
                time.sleep(0.5)
                continue

            ret, frame = self.cap.read()
            if not ret:
                time.sleep(0.05)
                continue

            frame = cv2.flip(frame, 1)
            raw_display = frame.copy()
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

            # 1. Deteccion de QR (si se muestra etiqueta QR impresa en pantalla o papel)
            qr_text = ""
            try:
                data, bbox, _ = self.qr_detector.detectAndDecode(frame)
                if data:
                    qr_text = data.strip()
                    if bbox is not None:
                        pts = bbox.astype(int).reshape(-1, 2)
                        cv2.polylines(raw_display, [pts], True, (0, 255, 0), 3)
            except Exception:
                pass

            # 2. Filtro de color HSV para Stream 2
            combined_mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
            detected_color = "NINGUNO"
            max_area = 2500  # Umbral minimo de pixeles para ignorar ruido

            colors_to_scan = (
                COLOR_RANGES_HSV.items()
                if self.active_color_filter == "TODOS"
                else [(self.active_color_filter, COLOR_RANGES_HSV[self.active_color_filter])]
            )

            for color_name, cfg in colors_to_scan:
                mask = cv2.inRange(hsv, cfg["lower"], cfg["upper"])
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
                mask = cv2.morphologyEx(mask, cv2.MORPH_DILATE, kernel)
                combined_mask = cv2.bitwise_or(combined_mask, mask)

                contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for cnt in contours:
                    area = cv2.contourArea(cnt)
                    if area > max_area:
                        max_area = area
                        detected_color = color_name
                        x, y, w, h = cv2.boundingRect(cnt)
                        cv2.rectangle(raw_display, (x, y), (x + w, y + h), cfg["bgr"], 3)
                        cv2.putText(
                            raw_display,
                            f"ETIQUETA: {color_name}",
                            (x, max(20, y - 10)),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            cfg["bgr"],
                            2,
                        )

            # Imagen filtrada (Stream 2): resalta unicamente los pixeles dentro del rango HSV
            filtered_display = cv2.bitwise_and(frame, frame, mask=combined_mask)
            # Anadir cuadricula de diagnostico en el stream filtrado
            cv2.putText(
                filtered_display,
                f"FILTRO HSV [{self.active_color_filter}] | DETECTADO: {detected_color}",
                (10, 28),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 255),
                2,
            )
            if qr_text:
                cv2.putText(
                    filtered_display,
                    f"QR: {qr_text[:38]}",
                    (10, 56),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (0, 255, 0),
                    2,
                )

            self.current_color = detected_color
            self.current_qr = qr_text if qr_text else "SIN_QR"

            # 3. Disparar evento hacia el administrador si hay deteccion valida y paso el cooldown
            now = time.time()
            if (detected_color != "NINGUNO" or qr_text) and (now - self.last_trigger_time > self.cooldown_seconds):
                self.last_trigger_time = now
                if self.on_detection_callback:
                    self.on_detection_callback(detected_color, qr_text)

            _, buf_raw = cv2.imencode(".jpg", raw_display, [cv2.IMWRITE_JPEG_QUALITY, 80])
            _, buf_flt = cv2.imencode(".jpg", filtered_display, [cv2.IMWRITE_JPEG_QUALITY, 80])

            with self.lock:
                self.raw_jpeg = buf_raw.tobytes()
                self.filtered_jpeg = buf_flt.tobytes()

            time.sleep(0.03)
